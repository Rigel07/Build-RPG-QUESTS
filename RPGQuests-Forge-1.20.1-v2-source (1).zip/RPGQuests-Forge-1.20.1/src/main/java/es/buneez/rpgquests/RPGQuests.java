package es.buneez.rpgquests;

import net.minecraftforge.fml.common.Mod;

@Mod(RPGQuests.MODID)
public class RPGQuests {
    public static final String MODID = "rpgquests";

    public RPGQuests() {
        QuestNetwork.register();
    }
}
