package es.buneez.rpgquests;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

public final class QuestCatalog {
    private QuestCatalog() {}

    // Objetivos contrastados con IDs presentes en los JAR personalizados del pack.
    // CRAFT/KILL/MINE se apoyan en estadísticas vanilla; COLLECT comprueba inventario.
    public static final List<Quest> ALL = List.of(
        new Quest("intro_01", "Una aventurera comienza", "Reúne 8 Pinkitas para iniciar tu aventura.", Quest.Type.COLLECT, "gemascute:pinkita", 8, 35, 4, ""),
        new Quest("intro_02", "Excavación brillante", "Pica 6 menas de Pinkita.", Quest.Type.MINE, "gemascute:pinkita_ore", 6, 55, 6, "intro_01"),
        new Quest("intro_03", "Equipo básico", "Fabrica un pico de hierro para continuar la expedición.", Quest.Type.CRAFT, "minecraft:iron_pickaxe", 1, 60, 6, "intro_02"),
        new Quest("intro_04", "Al Nether", "Viaja al Nether y reclama esta misión mientras estés allí.", Quest.Type.VISIT_DIMENSION, "minecraft:the_nether", 1, 100, 10, "intro_03"),

        new Quest("star_01", "Fragmentos del firmamento", "Reúne 3 fragmentos de estrella azul.", Quest.Type.COLLECT, "estrella_magica_fugaz:blue_star_fragment", 3, 45, 5, ""),
        new Quest("star_02", "Tallo estelar", "Consigue 4 pétalos estelares.", Quest.Type.COLLECT, "estrella_magica_fugaz:stellar_petal", 4, 65, 7, "star_01"),
        new Quest("star_03", "Forja astral", "Fabrica un báculo estelar.", Quest.Type.CRAFT, "astral:star_staff", 1, 110, 12, "star_02"),
        new Quest("star_04", "Reliquia cósmica", "Reúne una esquirla de esmeralda cósmica.", Quest.Type.COLLECT, "estrella_magica_fugaz:cosmic_emerald_shard", 1, 150, 16, "star_03"),

        new Quest("cute_01", "Una merienda adorable", "Consigue 4 mochis de fresa.", Quest.Type.COLLECT, "cute_realms:strawberry_mochi", 4, 40, 5, ""),
        new Quest("cute_02", "El dulce de la suerte", "Reúne 3 monedas de deseo.", Quest.Type.COLLECT, "cute_realms:wish_coin", 3, 55, 6, "cute_01"),
        new Quest("cute_03", "Cazador de estrellines", "Derrota 5 Estrellines de Cute Realms.", Quest.Type.KILL, "cute_realms:estrellin", 5, 90, 10, "cute_02"),

        new Quest("dragon_01", "Escamas de dragoncito", "Consigue 2 escamas de dragón rosa.", Quest.Type.COLLECT, "isladragoncitos:pink_dragon_scale", 2, 70, 8, ""),
        new Quest("dragon_02", "La isla tiene guardianes", "Derrota 3 dragoncitos.", Quest.Type.KILL, "isladragoncitos:dragoncito", 3, 125, 13, "dragon_01"),
        new Quest("dragon_03", "Un compañero alado", "Consigue un huevo generador de Dragoncito.", Quest.Type.COLLECT, "isladragoncitos:dragoncito_spawn_egg", 1, 145, 15, "dragon_02"),

        new Quest("uni_01", "Rastro de unicornio", "Reúne 4 unidades de polvo de unicornio.", Quest.Type.COLLECT, "superunicornios:polvo_de_unicornio", 4, 55, 6, ""),
        new Quest("uni_02", "Tras la criatura mágica", "Encuentra y derrota 2 unicornios.", Quest.Type.KILL, "superunicornios:unicorn", 2, 100, 10, "uni_01"),
        new Quest("uni_03", "Armadura estelar", "Consigue un casco estelar de unicornio.", Quest.Type.COLLECT, "superunicornios:casco_estelar", 1, 170, 18, "uni_02"),

        new Quest("gnome_01", "El rincón de los gnomos", "Encuentra 3 gnomos y derrota a los que amenacen el camino.", Quest.Type.KILL, "gnomos:gnome", 3, 55, 6, ""),
        new Quest("gnome_02", "Preparativos del viaje", "Consigue 3 panes de gnomo.", Quest.Type.COLLECT, "gnomos:gnome_bread", 3, 70, 7, "gnome_01"),
        new Quest("hoji_01", "Polvo mágico", "Reúne 4 unidades de polvo mágico de Hoji.", Quest.Type.COLLECT, "hoji:magic_dust", 4, 45, 5, ""),
        new Quest("hoji_02", "Criaturas del bosque", "Derrota 3 Hoji.", Quest.Type.KILL, "hoji:hoji", 3, 85, 9, "hoji_01"),

        new Quest("wonder_01", "Fragmentos de maravilla", "Reúne 3 fragmentos estelares de Maravillas.", Quest.Type.COLLECT, "maravillas:star_fragment", 3, 65, 7, ""),
        new Quest("wonder_02", "Núcleo de nube", "Consigue un núcleo de nube.", Quest.Type.COLLECT, "maravillas:cloud_core", 1, 105, 11, "wonder_01"),
        new Quest("wonder_03", "Guardián de las maravillas", "Derrota 3 criaturas de Maravillas del Mundo.", Quest.Type.KILL, "maravillas:wonder_mob", 3, 150, 16, "wonder_02"),
        new Quest("wonder_04", "Hacia el End", "Viaja al End y reclama esta misión allí.", Quest.Type.VISIT_DIMENSION, "minecraft:the_end", 1, 225, 24, "wonder_03"),

        new Quest("kawaii_01", "Dulces de aventura", "Consigue 5 galletas kawaii.", Quest.Type.COLLECT, "rinconeskawaii:galleta_kawaii", 5, 35, 4, ""),
        new Quest("kawaii_02", "Pastel de nube", "Reúne 2 pasteles de nube.", Quest.Type.COLLECT, "rinconeskawaii:pastel_de_nube", 2, 65, 7, "kawaii_01"),
        new Quest("kawaii_03", "Explorador de criaturas", "Derrota 5 criaturas Mochi de Cutemobs.", Quest.Type.KILL, "cutemobs:mochi", 5, 95, 10, "kawaii_02"),

        new Quest("rainbow_01", "Tesoro de colores", "Encuentra 3 gemas arcoíris.", Quest.Type.COLLECT, "treasure_rainbow:rainbow_gem", 3, 55, 6, ""),
        new Quest("rainbow_02", "Polvo de arcoíris", "Reúne 8 unidades de polvo de arcoíris.", Quest.Type.COLLECT, "treasure_rainbow:rainbow_dust", 8, 90, 10, "rainbow_01"),
        new Quest("cassy_01", "Huellas del pasado", "Reúne 4 fragmentos fósiles.", Quest.Type.COLLECT, "cassy:fossil_fragment", 4, 55, 6, ""),
        new Quest("cassy_02", "Expedición paleontológica", "Consigue 2 huesos de dinosaurio.", Quest.Type.COLLECT, "cassy:dino_bone", 2, 95, 10, "cassy_01"),

        new Quest("adventure_01", "Primeros pasos de aventurero", "Fabrica una espada de hierro.", Quest.Type.CRAFT, "minecraft:iron_sword", 1, 35, 4, ""),
        new Quest("adventure_02", "Defiende el camino", "Derrota 10 zombis.", Quest.Type.KILL, "minecraft:zombie", 10, 75, 8, "adventure_01"),
        new Quest("adventure_03", "Minero experto", "Pica 16 bloques de hierro en bruto.", Quest.Type.MINE, "minecraft:iron_ore", 16, 85, 9, "adventure_02"),
        new Quest("adventure_04", "La dimensión final", "Derrota al Dragón del End.", Quest.Type.KILL, "minecraft:ender_dragon", 1, 500, 64, "wonder_04")
    );

    public static ResourceLocation id(Quest quest) {
        return ResourceLocation.tryParse(quest.target());
    }

    public static Item item(Quest quest) {
        ResourceLocation id = id(quest);
        return id == null ? null : ForgeRegistries.ITEMS.getValue(id);
    }

    public static Block block(Quest quest) {
        ResourceLocation id = id(quest);
        return id == null ? null : ForgeRegistries.BLOCKS.getValue(id);
    }

    public static EntityType<?> entity(Quest quest) {
        ResourceLocation id = id(quest);
        return id == null ? null : ForgeRegistries.ENTITY_TYPES.getValue(id);
    }

    public static boolean targetExists(Quest quest) {
        return switch (quest.type()) {
            case COLLECT, CRAFT -> item(quest) != null && item(quest) != net.minecraft.world.item.Items.AIR;
            case MINE -> block(quest) != null && block(quest) != net.minecraft.world.level.block.Blocks.AIR;
            case KILL -> entity(quest) != null;
            case VISIT_DIMENSION -> id(quest) != null;
        };
    }

    public static int progress(Player player, Quest quest) {
        return switch (quest.type()) {
            case COLLECT -> count(player, item(quest));
            case CRAFT -> itemStat(player, quest);
            case KILL -> entityStat(player, quest);
            case MINE -> blockStat(player, quest);
            case VISIT_DIMENSION -> player.level().dimension().location().equals(id(quest)) ? 1 : 0;
        };
    }

    private static int count(Player player, Item item) {
        if (item == null || item == net.minecraft.world.item.Items.AIR) return 0;
        int total = 0;
        for (ItemStack stack : player.getInventory().items) if (stack.is(item)) total += stack.getCount();
        for (ItemStack stack : player.getInventory().armor) if (stack.is(item)) total += stack.getCount();
        for (ItemStack stack : player.getInventory().offhand) if (stack.is(item)) total += stack.getCount();
        return total;
    }

    private static int itemStat(Player player, Quest quest) {
        Item item = item(quest);
        return item == null || item == net.minecraft.world.item.Items.AIR ? 0 : player.getStats().getValue(Stats.ITEM_CRAFTED.get(item));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static int entityStat(Player player, Quest quest) {
        EntityType<?> type = entity(quest);
        return type == null ? 0 : player.getStats().getValue((net.minecraft.stats.Stat) Stats.ENTITY_KILLED.get(type));
    }

    private static int blockStat(Player player, Quest quest) {
        Block block = block(quest);
        return block == null || block == net.minecraft.world.level.block.Blocks.AIR ? 0 : player.getStats().getValue(Stats.BLOCK_MINED.get(block));
    }

    public static boolean isClaimed(Player player, String id) {
        return player.getPersistentData().getCompound("rpgquests").getBoolean(id);
    }

    public static boolean prerequisiteMet(Player player, Quest quest) {
        return quest.prerequisite().isBlank() || isClaimed(player, quest.prerequisite());
    }

    public static boolean consume(Player player, Quest quest) {
        Item item = item(quest);
        if (item == null || count(player, item) < quest.amount()) return false;
        int remaining = quest.amount();
        remaining = consumeFrom(player.getInventory().items, item, remaining);
        remaining = consumeFrom(player.getInventory().offhand, item, remaining);
        consumeFrom(player.getInventory().armor, item, remaining);
        return true;
    }

    private static int consumeFrom(List<ItemStack> stacks, Item item, int remaining) {
        for (ItemStack stack : stacks) {
            if (remaining <= 0) break;
            if (stack.is(item)) {
                int take = Math.min(remaining, stack.getCount());
                stack.shrink(take);
                remaining -= take;
            }
        }
        return remaining;
    }
}
