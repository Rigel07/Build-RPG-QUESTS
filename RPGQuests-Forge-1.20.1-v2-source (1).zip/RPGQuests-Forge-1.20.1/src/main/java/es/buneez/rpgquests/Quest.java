package es.buneez.rpgquests;

public record Quest(
        String id,
        String title,
        String description,
        Type type,
        String target,
        int amount,
        int xpReward,
        int emeraldReward,
        String prerequisite
) {
    public enum Type {
        COLLECT, CRAFT, KILL, MINE, VISIT_DIMENSION
    }
}
