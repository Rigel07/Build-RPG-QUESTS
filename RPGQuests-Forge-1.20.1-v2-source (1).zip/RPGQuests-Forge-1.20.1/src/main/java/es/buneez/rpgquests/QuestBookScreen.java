package es.buneez.rpgquests;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

public class QuestBookScreen extends Screen {
    private static final int PER_PAGE = 5;
    private int page = 0;
    private int panelX, panelY, panelW = 390, panelH = 286;
    private Button previous, next;

    public QuestBookScreen() {
        super(Component.literal("Diario de misiones RPG"));
    }

    @Override
    protected void init() {
        panelX = (width - panelW) / 2;
        panelY = Math.max(12, (height - panelH) / 2);
        QuestNetwork.CHANNEL.sendToServer(new RequestQuestStatePacket());
        rebuild();
    }

    public void refresh() { rebuild(); }

    private void rebuild() {
        clearWidgets();
        int totalPages = (QuestCatalog.ALL.size() + PER_PAGE - 1) / PER_PAGE;
        previous = addRenderableWidget(Button.builder(Component.literal("‹ Anterior"), b -> {
            page = Math.max(0, page - 1); rebuild();
        }).bounds(panelX + 12, panelY + panelH - 30, 95, 20).build());
        next = addRenderableWidget(Button.builder(Component.literal("Siguiente ›"), b -> {
            page = Math.min(totalPages - 1, page + 1); rebuild();
        }).bounds(panelX + panelW - 107, panelY + panelH - 30, 95, 20).build());
        previous.active = page > 0;
        next.active = (page + 1) * PER_PAGE < QuestCatalog.ALL.size();

        Player player = Minecraft.getInstance().player;
        if (player == null) return;
        int start = page * PER_PAGE;
        int end = Math.min(start + PER_PAGE, QuestCatalog.ALL.size());
        for (int i = start; i < end; i++) {
            Quest quest = QuestCatalog.ALL.get(i);
            boolean ready = QuestCatalog.targetExists(quest)
                && !QuestCatalog.isClaimed(player, quest.id())
                && QuestCatalog.prerequisiteMet(player, quest)
                && QuestCatalog.progress(player, quest) >= quest.amount();
            String label = QuestCatalog.isClaimed(player, quest.id()) ? "Completada"
                : !QuestCatalog.targetExists(quest) ? "Objetivo no disponible"
                : !QuestCatalog.prerequisiteMet(player, quest) ? "Bloqueada"
                : ready ? "Reclamar" : "En curso";
            Button claim = Button.builder(Component.literal(label), b -> {
                if (ready) {
                    QuestNetwork.CHANNEL.sendToServer(new ClaimQuestPacket(quest.id()));
                    Minecraft.getInstance().setScreen(null);
                }
            }).bounds(panelX + panelW - 105, panelY + 52 + (i - start) * 43, 92, 20).build();
            claim.active = ready;
            addRenderableWidget(claim);
        }
    }

    private String objectiveName(Quest q) {
        return switch (q.type()) {
            case COLLECT -> "Reunir";
            case CRAFT -> "Fabricado";
            case KILL -> "Derrotados";
            case MINE -> "Picados";
            case VISIT_DIMENSION -> "Visitar dimensión";
        };
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xEE171525);
        graphics.fill(panelX + 2, panelY + 2, panelX + panelW - 2, panelY + 34, 0xFF3D285A);
        graphics.drawCenteredString(font, "RPG DEFINITIVO — Diario de misiones", width / 2, panelY + 11, 0xFFFFD875);

        Player player = Minecraft.getInstance().player;
        int start = page * PER_PAGE;
        int end = Math.min(start + PER_PAGE, QuestCatalog.ALL.size());
        for (int i = start; i < end; i++) {
            Quest q = QuestCatalog.ALL.get(i);
            int y = panelY + 40 + (i - start) * 43;
            boolean claimed = player != null && QuestCatalog.isClaimed(player, q.id());
            boolean available = QuestCatalog.targetExists(q);
            int progress = player == null ? 0 : QuestCatalog.progress(player, q);
            String status;
            if (claimed) status = "§aCOMPLETADA";
            else if (!available) status = "§cOBJETIVO NO DISPONIBLE (revisar mod/ID)";
            else if (player != null && !QuestCatalog.prerequisiteMet(player, q)) status = "§7Bloqueada por misión anterior";
            else status = "§f" + objectiveName(q) + ": " + Math.min(progress, q.amount()) + "/" + q.amount()
                    + "   §6Recompensa: " + q.xpReward() + " XP, " + q.emeraldReward() + " esmeraldas";
            graphics.drawString(font, q.title(), panelX + 12, y, 0xFFFFFFFF, false);
            graphics.drawString(font, q.description(), panelX + 12, y + 11, 0xFFBFBAD0, false);
            graphics.drawString(font, status, panelX + 12, y + 23, 0xFFFFD875, false);
        }
        graphics.drawCenteredString(font, "Página " + (page + 1) + " / " + ((QuestCatalog.ALL.size() + PER_PAGE - 1) / PER_PAGE) + " | Pulsa J para abrir", width / 2, panelY + panelH - 7, 0xFFBFBAD0);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
