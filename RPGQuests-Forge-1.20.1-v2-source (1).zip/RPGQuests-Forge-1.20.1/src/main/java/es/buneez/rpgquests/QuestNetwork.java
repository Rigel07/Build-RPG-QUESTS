package es.buneez.rpgquests;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class QuestNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(RPGQuests.MODID, "main"),
        () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals
    );

    private static boolean registered = false;
    private QuestNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(0, ClaimQuestPacket.class,
            ClaimQuestPacket::encode, ClaimQuestPacket::decode, ClaimQuestPacket::handle);
        CHANNEL.registerMessage(1, RequestQuestStatePacket.class,
            RequestQuestStatePacket::encode, RequestQuestStatePacket::decode, RequestQuestStatePacket::handle);
        CHANNEL.registerMessage(2, SyncQuestStatePacket.class,
            SyncQuestStatePacket::encode, SyncQuestStatePacket::decode, SyncQuestStatePacket::handle);
    }
}
