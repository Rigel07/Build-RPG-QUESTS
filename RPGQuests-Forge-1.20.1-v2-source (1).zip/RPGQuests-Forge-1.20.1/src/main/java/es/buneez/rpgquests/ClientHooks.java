package es.buneez.rpgquests;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = RPGQuests.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientHooks {
    private static KeyMapping QUEST_KEY;

    private ClientHooks() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        QUEST_KEY = new KeyMapping("key.rpgquests.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.rpgquests");
        event.register(QUEST_KEY);
    }

    @Mod.EventBusSubscriber(modid = RPGQuests.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeEvents {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || QUEST_KEY == null) return;
            Minecraft mc = Minecraft.getInstance();
            while (QUEST_KEY.consumeClick()) {
                if (mc.player != null && mc.screen == null) mc.setScreen(new QuestBookScreen());
            }
        }
    }
}
